const axios = require('axios');

const url = "https://jsonplaceholder.typicode.com/posts/1";

dadosAtualizados = {
    title: "Titulo atualizado com PUT",
    body: "exemplo de uma requisição put ",
    userId: 2
}

axios.put(url, dadosAtualizados)
    .then(response => {
        console.log("recurso atualizado com sucesso");
        console.log(response.data)

    })
    .catch(error => {
        console.error(`erro ao tentar atualizar o recurso: ${error}`)

    })