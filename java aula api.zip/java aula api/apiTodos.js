const axios = require('axios');
const urlGet = "https://jsonplaceholder.typicode.com/todos/1"
const urlPost = "https://jsonplaceholder.typicode.com/posts"
const urlPut = "https://jsonplaceholder.typicode.com/posts/1"


axios.get(urlGet)
    .then(response => {

        console.log("dados recebidos da api: ")

        console.log(response.data)

    })
    .catch(error => {

        console.log(`erro ao acessar a API: ${error}`)


    })


const novoPost = {
    title: "josh é o astro da bahia",
    body: "incrível",
    userId: 1
}

axios.post(urlPost, novoPost)
    .then(response => {
        console.log("recurso criado com sucesso");
        console.log(response.data)
    })
    .catch(error => {
        console.error(`erro ao tentar criar o recurso: ${error}`)

    })
const dadosAtualizados = {
    title: "josh é o astro da bahia inteira",
    body: "incrível d+",
    userId: 1

}
axios.put(urlPut, dadosAtualizados)
    .then(response => {
        console.log("recurso atualizado com sucesso");
        console.log(response.data)

    })
    .catch(error => {
        console.error(`erro ao tentar atualizar o recurso: ${error}`)

    })




// delete

axios.delete(urlPut)
    .then(reponse => {
        //sucesso 
        console.log("recurso deletado com sucesso")
        console.log(`status da resposta: ${response.status}`)

    })
    .catch(error => {
        console.error(`erro ao tentar deletar o recurso: ${error}`)
    })

