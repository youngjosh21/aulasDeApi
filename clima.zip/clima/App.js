import * as React from 'react';
import { Text, View, StyleSheet, Image } from 'react-native';
import * as Location from 'expo-location'; // Expo Location API

export default class App extends React.Component {
  constructor() {
    super();
    this.state = {
      api: '',
      time: '',
      location: null,
      errorMessage: null,
    };
  }

  async componentDidMount() {
    await this.getLocation();
  }

  // Obtendo a localização atual
  getLocation = async () => {
    let { status } = await Location.requestForegroundPermissionsAsync();
    if (status !== 'granted') {
      this.setState({ errorMessage: 'Permissão negada' });
      return;
    }
    let location = await Location.getCurrentPositionAsync({});
    this.setState({ location }, () => {
      this.pegarDados();
      this.getTime();
    });
  };

  getTime = async () => {
    var timeApi = 'http://worldtimeapi.org/api/timezone/America/Sao_Paulo';

    return await fetch(timeApi)
      .then((response) => response.json())
      .then((responseJson) => {
        const dateTime = new Date(responseJson.datetime)
        this.setState({ time: dateTime.toLocaleString('pt-BR', { timeZone: 'America/Sao_Paulo' }) });
      })
      .catch((erro) => console.error(erro));      
  };

  // Pegando os dados da API com base na localização atual
  pegarDados = async () => {
    const { latitude, longitude } = this.state.location.coords;
    var link = `https://api.openweathermap.org/data/2.5/weather?lat=${latitude}&lon=${longitude}&units=metric&APPID=143454aa39bbe3442a890cdbf3f9db36`;

    return await fetch(link)
      .then((response) => response.json())
      .then((responseJson) => {
        this.setState({ api: responseJson });
      })
      .catch((erro) => console.error(erro));
  };

  render() {
    if (!this.state.api) {
      return (
        <View style = {styles.container}>
          <Text style = {styles.texto}> CARREGANDO..... </Text>
        </View>
      );
    } else {
      return (
        <View style = {styles.container}>
          <Text style = {styles.title}> PREVISÃO DO TEMPO </Text>
          <Image 
            style = {styles.imagem}
            source={require('./clima.png')} 
          />
          <Text style = {styles.texto}>
            {this.state.api.name} - {this.state.api.main.temp}°C
          </Text>           
          <Text style={styles.texto}>
            Hora local: {this.state.time}
          </Text>
        </View>
      );
    }
  }
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "black",
  },
  title: {
    marginTop: 50,
    fontSize: 25,
    fontWeight: 'bold',
    textAlign: 'center',
    color: 'white',
  },
  imagem: {
    width: 150,
    height: 150, 
    marginTop: 30,
    alignSelf: 'center',
    marginVertical: '30',
  },
  texto: {
    marginHorizontal: 20,
    fontSize: 20,
    textAlign: 'center',
    fontWeight: 'bold',
    color: 'white',
  },
});
